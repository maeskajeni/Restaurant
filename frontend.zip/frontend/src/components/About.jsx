import React from "react";
import { Link } from "react-router-dom";
import { HiOutlineArrowRight } from "react-icons/hi";

const About = () => {
  return (
    <>
      <section className="about" id="about">
        <div className="container">
          <div className="banner">
            <div className="top">
              <h1 className="heading">Seroja Resto</h1>
              <p>"Hidangan Lezat, Suasana Hangat".</p>
            </div>
            <p className="mid">
                Resto Lezat menawarkan berbagai hidangan khas dengan cita rasa otentik. 
                Kami berkomitmen untuk menyajikan makanan berkualitas tinggi dengan suasana yang nyaman dan ramah. 
                Nikmati pengalaman bersantap yang tak terlupakan bersama kami!
            </p>
            <Link to={"/"}>
              Explore Menu{" "}
              <span>
                <HiOutlineArrowRight />
              </span>
            </Link>
          </div>
          <div className="banner">
            <img src="about.png" alt="about" />
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
